from dataclasses import dataclass, field
from typing import Optional, Dict, List, Union


@dataclass
class DocumentChunk:
    """A chunk of a document.

    Document chunks are retrieved and returned as part of `RAGCompletionResponse` objects 
    which are returned by RAG Completion creation requests.
    
    Args:
        title (`str`):
            The title of the document chunk.
        content (`str`):
            The document chunk text.
        score (`float`):
            A relevance score between 0.0 and 1.0 representing how relevant this 
            chunk was determined to be with respect to answering the input query.
        metadata (`Optional[Dict]`, optional, defaults to `None`):
            Metadata tags associated with the document chunk.
    """

    title: str = field(
        metadata={
            'help': 'The document chunk title.'
        }
    
    )

    content: str = field(
        metadata={
            'help': 'The document chunk text.'
        }
    )

    score: float = field(
        metadata={
            'help': (
                'A relevance score between 0.0 and 1.0 representing '
                'how relevant the document chunk was determined to be '
                'with respect to answering the input query.'
            )
        }
    )

    metadata: Optional[Dict[str, Union[str, float, List, Dict]]] = field(
        default=None,
        metadata={
            'help': 'Metadata tags associated with the document chunk.'
        }
    )