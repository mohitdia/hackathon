import os

api_key = os.environ.get('BETA_AI_API_KEY', None)
api_base = os.environ.get('BETA_AI_API_BASE', None)

from .resource import (
    RAGCompletion,
    ChatCompletion
)

from .request import (
    RAGCompletionRequest,
    ChatCompletionRequest
)

from .exception import (
    BetaAIException,
    InvalidChatRequest,
    InvalidRAGRequest
)

# def init(api_key: str=None, api_base: str=None):
#     return None

__all__ = [
    'RAGCompletion',
    'ChatCompletion',
    'InvalidChatRequest',
    'InvalidRAGRequest',
    'BetaAIException',
    'RAGCompletionRequest',
    'ChatCompletionRequest'
]