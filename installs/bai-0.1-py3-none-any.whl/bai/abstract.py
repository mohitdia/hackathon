import logging
import time
import requests

from abc import ABCMeta, abstractmethod
from typing import Generator, Union

from . import (
    client,
    response,
    request,
    exception
)


logging.basicConfig(
    format="%(asctime)s - %(levelname)s: %(message)s", level=logging.INFO
)
logger = logging.getLogger('Resource')

class Resource(metaclass=ABCMeta):
    """A BetaAI API Resource.
    
    Abstractly defined - you will not directly have to implement your own
    instances of this superclass.
    """

    def __init__(self, api_base: str = None):
        """A BetaAI API Resource.
    
        Abstractly defined - you will not directly have to implement your own
        instances of this superclass.

        Args:
            api_base (str, optional): The BetaAI base API URL. Defaults to None.

        Raises:
            exception.BetaAIException: if no base API URL is supplied, and no base API env var is set
        """
        if not api_base:
            from . import api_base as env_api_base
            if not env_api_base:
                raise exception.BetaAIException(
                    'An API base was not supplied, and no API base environment variable was found. '
                    'Either try your request again with a supplied API base, or set your BETA_AI_API_BASE '
                    'environment variable.'
                )
            self.api_base = env_api_base
        else:
            self.api_base = api_base

    @property
    @abstractmethod
    def resource_path(self) -> str:
        """The API resource path

        Returns:
            str: The resource path for the API resource
        """
        ...

    @abstractmethod
    def _format_response(
        self, 
        response: requests.Response, 
        duration: float
    ) -> Union[response.ChatCompletionResponse, response.RAGCompletionResponse]:
        ...

    @abstractmethod
    def _prepare_request(
        self, 
        request: request.Request    
    ) -> dict:
        ...

    # Defined abstractly only for type-hinting purposes
    @abstractmethod
    def _create(
        self, 
        request: request.Request,
        api_key: str=None,
    ) -> Union[response.ChatCompletionResponse, response.RAGCompletionResponse, Generator]:
        ...

    @classmethod
    def create(
        cls,
        request: request.Request,
        api_base: str=None,
        api_key: str=None
    ) -> Union[response.ChatCompletionResponse, response.RAGCompletionResponse, Generator]:
        """Creates a new instance of this API resource by fulfulling an API request.

        Args:
            request (request.Request): Request parameters
            api_base (str, optional): BetaAI API base URL. Defaults to None.
            api_key (str, optional): BetaAI API Key. Defaults to None.

        Returns:
            response.ChatCompletionResponse | response.RAGCompletionResponse | Generator: Either a well-formed response object, or a generator over tokens (if the request is specified as a streaming request)
        """
        resource = cls(api_base=api_base)
        if not api_key:
            from . import api_key as env_api_key
            if not env_api_key:
                logger.warning(
                    'An API key was not supplied, and no API key environment variable was found. '
                    'It is recommended to supply your API key via environment variable by setting BETA_AI_API_BASE. '
                    'Unless you are debugging, your request is likely to fail!'
                )
            api_key = env_api_key
        return resource._create(request, api_key=api_key)
    
    def _request(
        self, 
        request: request.Request,
        api_key: str=None
    ):
        try:
            payload = self._prepare_request(request)
            stream = payload['stream']
            workspace_id = payload.pop('workspace_id')
            requestor = client.APIClient()
            url = f'{self.api_base}/{self.resource_path}'
            if stream:
                def generator():
                    for token in requestor.request(
                        url,  
                        data=payload,
                        stream=True,
                        api_key=api_key,
                        workspace_id=workspace_id
                    ):
                        # decoding based on Falcon token vocab - TODO make more adaptable once we host more models
                        decoded = token.decode('utf-8')
                        decoded = decoded.replace('<newlinechar>', '\n')
                        decoded = decoded.replace('<|endoftext|>', '')
                        decoded = decoded.replace('</s>', '')
                        yield decoded
                return generator()
            else:
                start = time.time()
                raw_response = requestor.request(
                    url,  
                    data=payload,
                    stream=False,
                    api_key=api_key,
                    workspace_id=workspace_id
                )
                duration = time.time() - start
                return raw_response, duration
        except Exception as ex:
            raise exception.BetaAIException(f'{type(ex)} - {ex}')