import requests


class APIClient:

    def request(self, url, data: dict, stream: bool=False, api_key: str=None, workspace_id: int=None):
        if api_key:
            headers = {
                'api-key': api_key
            }
        if workspace_id:
            headers['workspace-id'] = str(workspace_id)
        return requests.post(
            url, 
            data=data,
            headers=headers,
            stream=stream,
            verify=False
        )
        

